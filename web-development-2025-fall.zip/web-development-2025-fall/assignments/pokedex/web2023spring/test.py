from pathlib import Path
import csv

p = Path('.') / 'datasets' / 'The Complete Pokemon Dataset' / 'pokemon.csv'
print(p.absolute())
with open(p, 'r', encoding='utf-8') as csvfile:
    csv_reader = csv.reader(csvfile)
    header = next(csv_reader)
    for row in csv_reader:
        print(row)