from .models import Pokemon, PokemonImage
from .serializers import PokemonSerializer, PokemonImageSerializer

from django.shortcuts import get_object_or_404
from rest_framework import viewsets, mixins
from rest_framework.response import Response
from rest_framework.authentication import BasicAuthentication

class PokemonViewSet(mixins.ListModelMixin, mixins.RetrieveModelMixin, viewsets.GenericViewSet):
    serializer_class = PokemonSerializer
    authentication_classes = (BasicAuthentication,)
    queryset = Pokemon.objects.all()

    def list(self, request, ):
        queryset = Pokemon.objects.all()
        self.check_object_permissions(request, Pokemon)
        serializer = PokemonSerializer(queryset, many=True)
        return Response(serializer.data)

    def retrieve(self, request, pk=None):
        queryset = Pokemon.objects.all()
        queryset_tmp = get_object_or_404(queryset, id=pk)
        # queryset_tmp = get_object_or_404(queryset, pokedex_number=pk)
        self.check_object_permissions(request, Pokemon)
        print(queryset_tmp)
        serializer = PokemonSerializer(queryset_tmp)
        return Response(serializer.data)

class PokemonImageViewSet(mixins.ListModelMixin, mixins.RetrieveModelMixin, viewsets.GenericViewSet):
    serializer_class = PokemonImageSerializer
    authentication_classes = (BasicAuthentication,)
    queryset = PokemonImage.objects.all()

    def list(self, request, ):
        queryset = PokemonImage.objects.all()
        self.check_object_permissions(request, PokemonImage)
        serializer = PokemonImageSerializer(queryset, many=True)
        return Response(serializer.data)

    def retrieve(self, request, pk=None):
        queryset = PokemonImage.objects.all()
        # queryset_tmp = get_object_or_404(queryset, id=pk)
        queryset_tmp = get_object_or_404(queryset, name=pk)
        self.check_object_permissions(request, PokemonImage)
        serializer = PokemonImageSerializer(queryset_tmp)
        return Response(serializer.data)