from django.contrib import admin

from .models import Pokemon, PokemonImage

admin.site.register(Pokemon)
admin.site.register(PokemonImage)
