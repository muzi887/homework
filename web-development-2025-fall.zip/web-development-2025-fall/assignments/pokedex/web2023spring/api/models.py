
from django.db import models
import os 
import uuid
from pathlib import Path
import csv

# The Complete Pokemon Dataset

class Pokemon(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    name = models.CharField('The English name of the Pokemon', max_length=80)
    japanese_name = models.CharField('The Original Japanese name of the Pokemon', max_length=80)
    pokedex_number = models.IntegerField('The entry number of the Pokemon in the National Pokedex', null=True, blank=True)
    percentage_male = models.FloatField('The percentage of the species that are male. Blank if the Pokemon is genderless.', null=True, blank=True)

    def __str__(self):
        return self.name
    
    def init_db():
        pokemon_db = Path('.') / 'datasets' / 'The Complete Pokemon Dataset' / 'pokemon.csv'
        print('Pokemon data file: ', end='')
        print(pokemon_db.absolute())
        with open(pokemon_db, 'r', encoding='utf-8') as csvfile:
            csv_reader = csv.reader(csvfile)
            pokemon_header = next(csv_reader)
            for row in csv_reader:
                print(row[30], row[29], row[32], row[31])
                p = Pokemon()
                p.name = row[30]
                p.japanese_name = row[29]
                p.pokedex_number = row[32]
                if row[31] != '':
                    p.percentage_male = row[31]
                p.save()

class PokemonImage(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    name = models.CharField('The English name of the Pokemon', max_length=80)
    type1 = models.CharField('Type 1', max_length=80)
    type2 = models.CharField('Type 2', max_length=80, blank=True, null=True)
    img = models.ImageField('Image of the Pokemon', upload_to='static')

    def __str__(self):
        return self.name

    def init_db():
        pokemon_db = Path('.') / 'datasets' / 'Pokemon Image Dataset' / 'pokemon.csv'
        print('Pokemon data file: ', end='')
        print(pokemon_db.absolute())
        with open(pokemon_db, 'r', encoding='utf-8') as csvfile:
            csv_reader = csv.reader(csvfile)
            pokemon_header = next(csv_reader)
            for row in csv_reader:
                print(row)
                p = PokemonImage()
                p.name = row[0]
                p.type1 = row[1]
                if len(row) == 3:
                    p.type2 = row[2]
                p.img = 'static/' + row[0] + '.png'
                p.save()
