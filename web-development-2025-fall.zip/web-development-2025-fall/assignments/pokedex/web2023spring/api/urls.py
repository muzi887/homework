from django.conf.urls import include, url
from rest_framework import routers
from .views import PokemonViewSet, PokemonImageViewSet

router_pokemon = routers.DefaultRouter()
router_pokemon.register(r'pokemon', PokemonViewSet)
router_pokemon_image = routers.DefaultRouter()
router_pokemon_image.register(r'pokemon-img', PokemonImageViewSet)

urlpatterns = [
    url(r'^', include(router_pokemon.urls)),
    url(r'^', include(router_pokemon_image.urls)),
]