from rest_framework import serializers
from .models import Pokemon, PokemonImage

class PokemonSerializer(serializers.ModelSerializer):
    class Meta:
        model = Pokemon
        fields = ('id', 'name', 'japanese_name', 'pokedex_number', 'percentage_male')

class PokemonImageSerializer(serializers.ModelSerializer):
    class Meta:
        model = PokemonImage
        fields = '__all__'
