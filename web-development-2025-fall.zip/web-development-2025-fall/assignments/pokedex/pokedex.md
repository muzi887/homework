# 宝可梦图鉴

## 致谢

感谢 2021 级软件工程专业张岩同学为本作业编写示例代码。

## 注意

**本作业示例截图、示例操作过程忘更新了，仅供参考，请大家根据自己电脑的实际情况酌情更改。**

陈皓天保证下学期一定更新。**I promise!**

现在是 AI 时代，本实验主要学习对 AJAX、JavaScript 创建元素技术的理解。前端界面美化方面建议使用 AI 提高可是效果。

几个推荐的前端框架：

- Bootstrap - Twitter 开发的 CSS 框架，提供大量现成组件，适合快速构建响应式网站
- AXUI - 阿里巴巴开源的轻量级 UI 框架，提供丰富的组件和主题，适合构建企业级应用
- Tailwind CSS - 原子化 CSS 框架，提供丰富的工具类，适合灵活定制界面
- Layui - 经典模块化前端框架，提供丰富的 UI 组件和交互功能，适合快速开发后台管理系统

建议在页面内结合自身情况酌情添加。

## 简介

宝可梦是一款深受全球粉丝喜爱的游戏和动漫 IP。它以寻找、收集和训练神奇生物为主题，玩家可以在游戏中探索各种各样的地图、挑战其他训练师，最终成为宝可梦大师。每个宝可梦都有独特的属性、技能和特征，例如火、水、草、电等不同的属性，还有能力、性格、进化等特征。

宝可梦图鉴网站是一个非常有用的资源，它收集了所有宝可梦的详细信息，包括名字、属性、能力、进化链、攻击、防御等等。通过这个网站，玩家可以更加深入地了解每个宝可梦的特征和技能，帮助他们做出更好的训练和战斗决策。此外，宝可梦图鉴还提供了一个方便的搜索功能，使玩家可以快速找到自己需要的宝可梦信息。无论是新手还是老手，宝可梦图鉴都是一个不可或缺的资源，可以帮助玩家更好地掌握这个精彩的游戏世界。

![image-20230513223132704](./.assets/image-20230513223132704.png)

## 基本要求

1. 本地配置 miniconda 运行环境
2. 在 miniconda 的虚拟环境内运行 django 服务器
3. 使用 CSS 表格技术建立单页面应用
4. 通过 AJAX 技术读取 API 得到宝可梦列表和宝可梦相关信息
5. 页面左侧为宝可梦列表
6. 页面右侧为宝可梦信息。点击左侧列表种宝可梦名称后，右侧显示该宝可梦的信息，包括：英文名、日语名、类型一、类型二（如果有）、性别比、图片信息
7. 美化网页

**注意**：示例图片内容可能已过期，请大家根据实际情况自行调整目录、文件名相关内容的命令行。

## 评分标准

| 编号 | 描述                                                                                           | 分值 | 提交文件      | 备注                                                                           |
| ---- | ---------------------------------------------------------------------------------------------- | ---- | ------------- | ------------------------------------------------------------------------------ |
| 1    | 正确安装 miniconda 运行环境                                                                    | 5    | `1.png`       | 需要桌面截图：终端内显示`(base) C:\Users\[用户名]>`                            |
| 2    | 正确下载课程代码，配置虚拟环境                                                                 | 5    | `2.png`       | 需要桌面截图：终端内显示`(django2023spring) C:\Users\[用户名]>`                |
| 3    | 在虚拟环境内运行 Django 服务器                                                                 | 5    | `3.png`       | 需要桌面截图：终端内显示`python manage.py runserver`运行结果                   |
| 4    | 有一个`index.html` 文件                                                                        | 5    | `index.html`  |                                                                                |
| 5    | 使用 CSS 表格技术建立包含 header、sidebar、main、footer 在内的分栏页面                         | 5    | `4.png`       | 需要桌面截图：显示 CSS 表格建立的核心代码                                      |
| 6    | 构建 RESTful 架构单页面应用，在左侧分栏内显示宝可梦列表（至少 20 项）                          | 5    | `5.png`       | 需要桌面截图：显示`fetch`代码，显示页面运行结果                                |
| 7    | 在左侧分栏内显示全部宝可梦名称，使用 LocalStorage 技术增加分页功能                             | 5    | `6.png`       | 需要桌面截图：显示 LocalStorage 代码，显示不同分页的对比（左右两个浏览器页面） |
| 8    | 在对左侧分栏内容设置`onclick`属性，实现点击展示右侧宝可梦信息                                  | 5    | `7.png`       | 需要桌面截图：对浏览器页面截图，显示核心代码                                   |
| 9    | 在右侧分栏内显示左侧分栏选中宝可梦的英文名、日语名、类型一、类型二（如果有）、性别比、图片信息 | 10   | `8.png`       | 需要桌面截图：对整个网页截图，每个宝可梦属性记 2 分                            |
| 10   | 页面简洁大方，header、footer 内包含宝可梦相关内容                                              | 10   | `9.png`       | 需要桌面截图：最终结果                                                         |
| 11   | 实验报告内容完整，包含实验目的、环境配置、实现过程、遇到的问题及解决方案                       | 10   | `report.md`   | 实验报告需包含完整的实验过程记录和代码说明                                     |
| 12   | 实验报告格式规范，包含目录、代码块、截图等必要元素                                             | 10   | `report.md`   | 使用 Markdown 格式编写，包含必要的代码高亮和截图说明                           |
| 13   | 实验报告中对关键技术的说明和解释                                                               | 10   | `report.md`   | 对 AJAX、LocalStorage、CSS 表格等关键技术进行详细说明                          |
| 14   | 实验报告中对实现效果的展示和分析                                                               | 10   | `report.md`   | 包含完整的页面效果展示和功能分析                                               |
| 15   | 前端项目文件夹**删除临时文件后**打包为 `project.zip`                                           | 0    | `project.zip` |                                                                                |
| 16   | 实验报告连同素材打包为 `report.zip`                                                            | 0    | `report.zip`  |                                                                                |

网页文件命名为`index.html`，命名错误不得分。

将作业作为项目，项目 **删除临时文件后** 打包为 `project.zip`，体积控制在 2M 以内。

实验报告文件命名为`report.md`，使用 Markdown 格式编写，需包含完整的实验过程记录、代码说明和效果展示。

本次作业满分 60 分，其中功能实现部分 40 分，实验报告部分 20 分。

最终页面效果如下图所示：

![pokemon_web.drawio](./.assets/pokemon_web.drawio.png)

以上排版方式仅是网页大致分栏，具体网页样式请自行设计。

## 实验步骤

### Windows 10 + Miniconda + Django 服务器端配置

访问[Miniconda - conda documentation](https://docs.conda.io/en/latest/miniconda.html)下载 Miniconda3 Windows 64-bit 安装包。

![Screenshot](./.assets/Screenshot.png)

下载后得到`Miniconda3-latest-Windows-x86_64.exe`。

![Screenshot](./.assets/Screenshot-1684030678383-8.png)

双击执行`Miniconda3-latest-Windows-x86_64.exe`，点击`I Agree`。

![2](./.assets/2.png)

选择`Just Me (recommended)`，然后`Next >`。

![3](./.assets/3.png)

选择安装目录。这里的`chenh`是根据计算机用户名自动生成的，在每台电脑上都不一样，因此需要记录好安装目录，例如：`C:\Users\Chenh\miniconda3`。点击`Next >`继续。

![4](./.assets/4.png)

使用默认设置，点击`Install`开始安装。

![5](./.assets/5.png)

开始安装，安装速度由电脑性能决定，耐心等待。

![6](./.assets/6.png)

安装完成后点击`Next >`继续下一步。

![7](./.assets/7.png)

完全安装完成，点击`Finish`完成整个安装过程。

![8](./.assets/8.png)

点击 Windows 操作系统左下角的开始按钮，在安装的应用程序里找到`Anaconda Powershell Prompt (miniconda3)`，单击运行 Powershell 版 conda 环境。

![9](./.assets/9.png)

进入 Powershell 版 conda 终端。注意：

- 此时使用 conda 基础环境，因此提示符前面有`(base)`字样
- `chenh`是演示计算机用户，`C:\Users\chenh>`为演示计算机用户主目录，不同计算机会有所不同。

![10](./.assets/10.png)

**可选：**根据[清华大学开源镜像站——Anaconda 镜像使用帮助](https://mirrors.tuna.tsinghua.edu.cn/help/anaconda/)和[清华大学开源镜像站——PyPI 镜像使用帮助](https://mirrors.tuna.tsinghua.edu.cn/help/pypi/)分别设置 conda 和 pip 的国内源。

在终端内使用`conda install git`安装 conda 版 git 工具。

![11](./.assets/11.png)

使用 git 命令`git clone http://iesast:1780/chenhaotian/web-development-2024-fall `克隆课程代码。

![12](./.assets/12.png)

进入课程代码目录`web-development-2024-fall`内的 Django 项目目录`web2023spring`，命令：`cd web-development-2024-fall\web2023spring`。

![13](./.assets/13.png)

回到 Powershell 终端，使用`environment.yml`创建虚拟环境，命令：`conda env create -f environment.yml`。

![15](./.assets/15.png)

创建完成后，使用`conda activate django2023spring`激活虚拟环境。

![16](./.assets/16.png)

执行`python manage.py runserver`开启服务器进程。

![17](./.assets/17.png)

此时，可以使用浏览器访问`http://127.0.0.1:8000/swagger/`查看服务器提供的 API。

![18](./.assets/18.png)

### 接口使用

###### API1：`http://127.0.0.1:8000/api/pokemon-img/`

收到宝可梦的列表信息。

其中每个宝可梦的信息包括`id`、`name`、`type1`、`type2`。

数据样例：

```json
[
  {
    "id": "b3f17fbc-5c7c-476d-be1f-d323f6793de4",
    "name": "bulbasaur",
    "type1": "Grass",
    "type2": "Poison",
    "img": "/static/bulbasaur.png"
  },
  {
    "id": "e0407e16-0d18-4c5f-b692-ce22ba2570f3",
    "name": "ivysaur",
    "type1": "Grass",
    "type2": "Poison",
    "img": "/static/ivysaur.png"
  },
  ...
]
```

###### API2：`http://127.0.0.1:8000/api/pokemon-img/<name>`

通过特定`<id>`取得特定宝可梦的信息。

例如：

`http://127.0.0.1:8000/api/pokemon-img/bulbasaur/`返回：

```json
{
  "id": "b3f17fbc-5c7c-476d-be1f-d323f6793de4",
  "name": "bulbasaur",
  "type1": "Grass",
  "type2": "Poison",
  "img": "/static/bulbasaur.png"
}
```

返回 json 中`"img"`字段为宝可梦图片的地址。可以通过字符串求和操作得到完整的宝可梦图片地址。

例如：`"img": "/static/bulbasaur.png"`=>`http://127.0.0.1:8000/static/bulbasaur.png`。

![19](./.assets/19.png)

###### API3：`http://127.0.0.1:8000/api/pokemon/`

收到宝可梦的列表信息。

其中每个宝可梦的信息包括`name`、`japanese_name`、`pokedex_number`、`percentage_maile`。

```json
[
  {
    "id": "dafec972-2e4d-45b5-b020-78d0dac58532",
    "name": "Bulbasaur",
    "japanese_name": "Fushigidaneフシギダネ",
    "pokedex_number": 1,
    "percentage_male": 88.1
  },
  {
    "id": "d833049a-9e53-4a28-be99-91e78443ce14",
    "name": "Ivysaur",
    "japanese_name": "Fushigisouフシギソウ",
    "pokedex_number": 2,
    "percentage_male": 88.1
  },
  ...
]
```

###### API4：`http://127.0.0.1:8000/api/pokemon/<id>`

通过特定`<id>`取得特定宝可梦的信息。

例如：

`http://127.0.0.1:8000/api/pokemon/dafec972-2e4d-45b5-b020-78d0dac58532/`返回：

```json
{
  "id": "dafec972-2e4d-45b5-b020-78d0dac58532",
  "name": "Bulbasaur",
  "japanese_name": "Fushigidaneフシギダネ",
  "pokedex_number": 1,
  "percentage_male": 88.1
}
```

## 参考资料

- [使用 uWSGI 和 nginx 来设置 Django 和你的 web 服务器](https://uwsgi-docs-zh.readthedocs.io/zh_CN/latest/tutorials/Django_and_nginx.html)
- [Django documentation](https://docs.djangoproject.com/en/3.2/)
- [宝可梦图鉴](https://www.pokemon.cn/play/pokedex)
- [kaggle - Pokemon with stats](https://www.kaggle.com/datasets/abcsds/pokemon)
- [kaggle - Pokemon Image Dataset](https://www.kaggle.com/datasets/vishalsubbiah/pokemon-images-and-types)
