# 布局与定位

## 致谢

感谢 2022 级软件工程专业李思雨同学为本作业编写示例代码。

## 基本要求

请根据以下要求完成作业：

1. 尝试`float`属性和`clear`属性
2. 尝试流体布局
3. 尝试凝胶布局
4. 尝试绝对定位
5. 尝试 CSS 表格显示
6. 尝试 flex 布局

注意：

1. 上传内容：截图（png 格式）、代码，评分同时参考截图和代码，缺代码、缺截图、截图不符合要求皆不得分；
2. 截图要求：

- 对整个桌面截图（露出右下角时间），
- 包含：
  1.  浏览器及网页;
  2.  代码编辑器及核心代码（核心代码即本文档中给出的代码，需在截图中有所体现)

3. 请自行保留好提交的文件，万一系统挂了方便重新提交^\_^

## 详细步骤

## 0.下载

从课程 Git 项目下载 `starbuzz.zip`。下载后`index.html`渲染效果如下：

![image-20240510105701254](assets/image-20240510105701254.png)

## 1.流体布局

1.在`index.html`中，`<div id="sidebar">`移动到`<div di="header">`下面

![image-20240510105755064](assets/image-20240510105755064.png)

2.`<div id="sidebar">`宽度设置为`280px`，增加向右的`float`属性

![image-20240510105938468](assets/image-20240510105938468.png)

3.`<div id="main">`右侧外边界设置为`330px`

![](assets/image-20240510110020309.png)

4.为`<div id="footer">`设置向右的 clear 属性

![image-20240510110145273](assets/image-20240510110145273.png)

## 2.冻结布局（frozen layouts）

1. 增加一个新的`<div id="allcontent">`元素，将`<div id="header">`、`<div id="sidebar">`,` <div id="main">``<div id="afooter"> `元素放置于`<div id="allcontent">`内

   ```html
   <body>
     <div id="allcontent">...rest of the HTML goes here...</div>
   </body>
   ```

2. 为`<div id="allcontent">`设置样式

   ```4css
   #allcontent {
       width: 800px;
       padding-top: 5px;
       padding-bottom: 5px;
       background-color: #675c47;
   }

   ```

![](assets/20240511095527.png)

## 3.凝胶布局

1. 为`<div id="allcontent">`增加样式`margin-left:auto;margin-right:auto`

![](assets/20240511095541.png)

## 4.绝对定位

1. `index.html`恢复到初始状态
2. `<div id="sidebar">`设置样式：

```css
position: absolute;
top: 100px;
right: 200px;
width: 280px;
```

![image-20240510110651105](assets/image-20240510110651105.png)

## 5. CSS 表格显示

CSS 表格显示允许在一个有行和列的表格中显示块元素，通过将内容放在一个 CSS 表格中，可以很容易地用 HTML 和 CSS 创建多栏设计。

1. `index.html`恢复到初始状态
2. 增加两个新的`<div>`容器并设置样式

   ```html
   <div id="tableContainer">
     <div id="tableRow">
       <div id="main">...</div>
       <div id="sidebar">...</div>
     </div>
   </div>
   ```

   ```css
   #tableContainer {
     display: table;
     border-spacing: 10px;
   }
   #tableRow {
     display: table-row;
   }
   ```

3. 去掉 CSS 表格内容（`<div id="sidebar">`和`<div id="main">`）的外边界（`margin`），设置为 CELL 表格内容（`display:table-cell`），增加上边对齐（`vertical-align: top;`）。这样，两边的内容就一样高。

![image-20240510111059787](assets/image-20240510111059787.png)

## 6.Flex 布局

1. `index.html`恢复到初始状态，新增一个容器：

```html
<div id="container">
  <div id="main"></div>
  <div id="sidebar"></div>
</div>
```

2. 容器的样式设置为`flex`，水平主轴。

```css
#container {
  display: flex;
  flex-direction: row;
}
```

3. 为`#main`和`#sidebar`增加`flex`样式，力争这俩能够成 1:2 比例。同时，也可以演示其它比例。

```css
#main {
  flex: 2 1 200px;
}
#sidebar {
  flex: 1 0.5 100px;
}
```

![image-20240510111442093](assets/image-20240510111442093.png)

## 7.提交样例

![image-20240510114421812](assets/image-20240510114421812.png)

对桌面进行截图，在浏览器中体现对应布局的特点，同屏在编辑器中体现核心代码。每个布局仅保留一张桌面截图。

## 评分标准

作业将按照以下标准进行评分：（每项只提交一张截图，对桌面进行截图，在浏览器中体现对应布局的特点，同屏在编辑器中体现核心代码。每个布局仅保留一张桌面截图。
）

| 编号 | 描述               | 分值 | 备注                                                                                                    |
| ---- | ------------------ | ---- | ------------------------------------------------------------------------------------------------------- |
| 1    | 流体布局的截图     | 10   | 桌面截图，显示网页效果，显示核心代码，文件名：`1.png`                                                   |
| 2    | 冻结布局的截图     | 10   | 桌面截图，显示网页效果，显示核心代码，截图中明显体现`<div id="allcontent">`两侧边距不同,文件名：`2.png` |
| 3    | 凝胶布局的截图     | 10   | 桌面截图，显示网页效果，显示核心代码，截图中明显体现`<div id="allcontent">`两侧边距相同,文件名：`3.png` |
| 4    | 绝对定位的截图     | 10   | 桌面截图，显示网页效果，显示核心代码，文件名：`4.png`                                                   |
| 5    | CSS 表格显示的截图 | 10   | 桌面截图，显示网页效果，显示核心代码，文件名：`5.png`                                                   |
| 6    | Flex 布局的截图    | 10   | 桌面截图，显示网页效果，显示核心代码，文件名：`6.png`                                                   |

## 实验报告内容与格式要求

请使用 Markdown 撰写实验报告，并包含以下内容：

1. 实验基本信息（5 分）
   - 姓名、学号、班级
   - 实验名称：布局与定位
   - 实验日期：2025 年 x 月 x 日（桌面截图右下角有时间，请和真实时间保持一致）
2. 实验环境说明（5 分）

   - 操作系统（如 Windows 11/macOS/Linux）
   - 浏览器（如 Chrome 123.0）
   - 编辑器（如 VS Code）

3. 实验过程描述（20 分）
   1. 逐项描述以下六种布局的操作过程，每项不少于 50 字，描述要包括：
      - 操作步骤简述（如修改了哪些 HTML/CSS）
      - 预期效果与实际效果
      - 遇到的问题与解决方法（如有）
   2. 布局项目如下：
      - 流体布局（float + clear）
      - 冻结布局（fixed width container）
      - 凝胶布局（margin auto）
      - 绝对定位布局（position: absolute）
      - CSS 表格显示布局（display: table, table-row, table-cell）
      - Flex 布局（display: flex）
4. 总结与感想（10 分）
   - 简要总结本次实验的收获（不少于 100 字），可结合具体布局方式谈体会，例如：
     - 各布局优缺点
     - 在实际开发中可能的应用场景
     - 对前端布局的整体理解有何提升
