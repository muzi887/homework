# 我最喜欢的诗

## 基本要求

请根据以下要求完成作业：

1. 下载安装[Visual Studio Code](https://code.visualstudio.com/)、[WebStorm](https://www.jetbrains.com/webstorm/)、[HBuilder](https://www.dcloud.io/hbuilderx.html)、[Chrome](https://www.google.cn/chrome/index.html)、[Firefox](https://www.mozilla.org/en-US/firefox/new/)，选择合适的开发工具
2. 创建`index.html`
3. 挑选一首自己喜欢的诗
4. 按照标题->作者->相关图片->诗词内容的顺序自上而下填充网页
5. 使用`<h1>`标签定义标题
6. “相关图片”从网上自选，内容应与所选诗词相近
7. 选择诗词中自己最喜欢的一句话，设定`style`属性为红色、加粗
8. 在`<head>`元素内，通过注释插入自己的学号、姓名
9. 在`<head>`元素内，设置`<title>`元素，内容为：我的第一个网页
10. 使用`style`属性美化网页，如背景、字号、字体等

## 评分标准

作业将按照以下标准进行评分：

| 序号 | 描述                                                                                         | 分值 | 提交文件                   | 备注                                                                                  |
| ---- | -------------------------------------------------------------------------------------------- | ---- | -------------------------- | ------------------------------------------------------------------------------------- |
| 1    | 有一个 html 文件                                                                             | 5    | `index.html`               |                                                                                       |
| 2    | html 文件内容是一首诗                                                                        | 5    | `index.html`               |                                                                                       |
| 3    | 使用 style 属性红色、加粗诗中的某一句话                                                      | 5    | `index.html`               |                                                                                       |
| 4    | 在`<head>`标签内通过注释插入学号、姓名                                                       | 5    | `index.html`               |                                                                                       |
| 5    | 在`<head>`元素内，设置`<title>`元素，内容：我的第一个网页                                    | 5    | `index.html`               |                                                                                       |
| 6    | 使用 style 属性美化网页                                                                      | 40   | `index.html`               | 除序号 2 要求外，每为一个元素设置一个不同 style 属性加 10 分，最高 30 分              |
| 7    | 下载使用 Visual Studio Code 编写代码，安装配置 open in browser、Prettier、Image preview 插件 | 5    | `1.png`                    | 桌面截图，显示左侧 Extensions 侧边栏                                                  |
| 8    | 使用 WebStrom 编辑器编写代码，使用 Chrome 浏览器预览结果                                     | 5    | `2.png`                    | 桌面截图                                                                              |
| 9    | 使用 Windows 操作系统预装“记事本”编写代码，Firefox 浏览器预览结果                            | 5    | `3.png`                    | 桌面截图                                                                              |
| 10   | 下载并使用 HBuilder 编写代码，展开 preview 页面                                              | 5    | `4.png`                    | 桌面截图                                                                              |
| 11   | 网页整体效果截图                                                                             | 0    | `5.png`                    | 桌面截图                                                                              |
| 12   | 实验报告图                                                                                   | 15   | `report.pdf`、`report.zip` | Markdown 格式实验报告（包含附件，打包为 `report.zip`），Typora 导出 `report.pdf` 文档 |

## 实验报告要求

### 主题

撰写一份《我的第一个网页开发总结》实验报告，使用 Markdown 语法完成。内容需围绕本次“我最喜欢的诗”网页制作过程展开，总结开发体验、遇到的问题及解决方法、收获与反思。

### 基本要求

1. 文档格式：使用 Markdown 语言编写，文件名为 `report.md`。
2. 报告内容：
   1. 标题（使用#标记，如 # 我的第一个网页开发总结）
   2. 基本信息（学号、姓名、实验时间，使用列表或者表格呈现）
   3. 实验目的（简述本次作业目标）
   4. 实验环境（列出使用的软件工具、浏览器等）
   5. 操作步骤与过程（简要描述网页制作过程，配图，插入两张截图）
   6. 遇到的问题及解决办法（至少写出两个问题及处理方式）
   7. 实验心得与收获（不少于 150 字）
3. 图片要求：
   1. 至少插入两张实验过程或结果的图片（如网页预览截图、编辑器截图）。
   2. 使用 Markdown 的图片语法插入，如：![描述信息](路径或URL)。
4. 排版规范：
   1. 使用标题、列表、粗体、斜体等 Markdown 基础格式。
   2. 合理分段，条理清晰，便于阅读。
5. 文件提交：
   1. Markdown 文件名：`report.md`
   2. 附加图片在相同目录内，文档内使用相对路径
   3. Markdown 文件、图片打包为 `report.zip`
   4. 使用 Typora 导出为 `report.pdf`
   5. 提交 `report.zip` 和 `report.pdf`

## 扩展练习

扩展练习属于课外推荐练习，不计入评分。

### 扩展练习 1：AI 生成内容

尝试使用 AI 分别生成文字和图片，代替“我最喜欢的诗”。

1. 登录[ChatGPT](https://chat.openai.com/)，使用 AI 生成一首描述软件工程专业学习的诗
2. 登录[Midjourney](https://www.midjourney.com/)，使用 AI 技术生成诗词相关图片（需要付费，10 刀）

### 扩展练习 2：Markdown 转 HTML

Markdown 是一种轻量级的标记语言，最初由约翰·格鲁伯（John Gruber）和亚伦·斯沃茨（Aaron Swartz）于 2004 年创建。它的设计目标是简单易读易写，并且可以轻松转换成 HTML 等其他格式。Markdown 语法简洁明了，包含了一些基本的标记和符号，如井号（`#`）用于标题、星号（`*`）和下划线（`_`）用于强调、方括号（`[]`）和括号（`()`）用于链接等。它不像 HTML 那样复杂，更加便于书写和编辑文本。

将 Markdown 文档转换为 HTML 一般经过以下过程：

1. 解析：将 Markdown 文本解析为一棵抽象语法树（AST），这是一个表示文本结构的树形数据结构。解析器会根据 Markdown 语法规则，将文本分析成一系列的语法节点，例如标题、段落、列表、链接等。
2. 转换：遍历抽象语法树，将 Markdown 语法节点转换成相应的 HTML 标签。例如，将 Markdown 中的井号（`#`）转换为 HTML 的`<h1>`、`<h2>`等标题标签，将星号（`*`）和下划线（`_`）转换为 HTML 的 em 和 strong 标签用于表示强调文本等。
3. 渲染：将转换后的 HTML 标签和内容渲染成最终的 HTML 文档。这一步通常会应用 CSS 样式表来控制文档的样式和布局，从而呈现出最终的页面效果。

简单来讲，Markdown 就是一个使用更简化语法生成 HTML 文档。在本练习中，我们希望**手动**模拟这个过程。

### 扩展练习 3：docx 文档转 HTML

docx 文档、XML（Extensible Markup Language）和 Office Open XML（OOXML）之间有着密切的关系。

1. docx 文档是一种由微软公司开发的 Microsoft Word 文档格式，用于存储文本、图像、表格、图形等多种元素的文件。docx 文档实际上是一个使用 XML 语法进行组织和存储的压缩文件，其中包含了文本、图像、表格等多种元素，并通过 XML 标签和属性来描述和定义这些元素的结构、样式和格式。
2. XML 是一种标记语言，用于描述和存储数据。在 docx 文档中，实际的文本内容、格式和样式信息都以 XML 格式进行存储。通过解析和处理 XML，可以对 docx 文档进行编辑、提取和转换等操作。
3. Office Open XML（OOXML）是一种基于 XML 的开放文档格式标准，用于描述和存储 Microsoft Office 软件中的文档、电子表格、演示文稿等文件。docx 文档正是基于 OOXML 标准开发的，它采用了 OOXML 的格式规范和结构，使用 XML 来描述和定义文档中的内容、格式和样式。

XML 是 docx 文档中存储和组织文本和样式信息的基础，而 Office Open XML 则是 docx 文档采用的标准格式规范。通过解析和处理 XML，可以对 docx 文档进行编辑和处理，保证文档的格式和样式的正确性。在 Microsoft Word 等软件执行渲染过程，所见即所得地渲染符合 Office Open XML 规范的 XML 文档。在本练习中，我们希望**手动**模拟这个过程。建议练习步骤：

1. 访问[河北地质大学重修管理办法](https://jwc.hgu.edu.cn/info/1121/2198.htm)，下载`.pdf`文档
2. 该 pdf 文档由 WPS 编写并输出（渲染）为 pdf，输出前也是一个符合 Office Open XML 规范的文档
3. 思考渲染输出文件和 HTML 标签的对应关系
4. 新建`作业一b.html`，使用 HTML 模仿《河北地质大学学生重修管理办法》第一页

## 参考资料

- 高海萍, 张云燕. 毛泽东的书单[M]. 北京: 新华出版社, 2014
- [Midjourney 保姆级使用教程](https://www.bilibili.com/video/BV1Ps4y1D79A/?share_source=copy_web&vd_source=919652c7f9820eec2d6d8b895a7150a5)
- [Markdown 介绍](https://en.wikipedia.org/wiki/Markdown)
- [Markdown 教程](https://www.runoob.com/markdown/md-tutorial.html)
- [Typora 官方中文站](https://typoraio.cn/)
- [通过 XML 构建`.docx`文档 - Office Open XML](https://zh.wikipedia.org/zh-hk/Office_Open_XML)
- [浅谈 Word docx 文件格式](https://www.uuu.com.tw/Public/content/article/22/20220523.htm)
- [河北地质大学重修管理办法](https://jwc.hgu.edu.cn/info/1121/2198.htm)
