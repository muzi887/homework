# Phaser 游戏开发

感谢 2023 级软件工程专业闫志恒同学撰写示例代码。

## 实验要求

使用三方 JavaScript 库 [Phaser](https://phaser.io/) 完成一个简单的网页小游戏的制作。官网内有详细教学，大家可以自行学习并且深入了解 Phaser 库的使用方法。

请按照以下要求完成实验：

1. 添加资源，丰富游戏画面
2. 添加音效资源，增加游戏趣味性
3. 编写 update 函数代码实现人物的动态控制，即使用方向键控制角色
4. 使用 overlap 事件控制游戏分数、游戏进程、游戏状态
5. 为自己的游戏写一个游戏规则说明（你也可以理解为语言表达能力考察）
6. **游戏不能仅仅是示例项目换素材**

注意事项：

1. 上传内容：代码截图、游戏效果截图、游戏运行视频、源代码文件、游戏资源文件、游戏说明文件
2. 截图要求：
   - 务必使用 Windows 自带的截图工具进行全屏截图，审查作业时会检查截图像素比例
   - 截图时请关闭透明任务栏/隐藏任务栏功能，确保底部状态栏清晰展示
3. 做好提交作业的备份工作，以防系统出错导致的作业丢失

## 评分标准

作业按照如下要求进行评分，部分评分点使用 AI 辅助检测，务必按照要求完成：

| 编号 | 评分点                                   | 分值 | 提交文件                   | 备注                                                                                                                                                      |
| ---- | ---------------------------------------- | ---- | -------------------------- | --------------------------------------------------------------------------------------------------------------------------------------------------------- |
| 1    | 网页效果截图                             | 10   | `1.png`                    | 使用浏览器运行后截图全屏                                                                                                                                  |
| 2    | 游戏中人物可以左右移动，并且朝向可以改变 | 10   | `2.png`, `3.png`           | 可以使用系统函数 `setFlipX()` 进行方向反转面向，也可以使用两张素材。人物向左、向右各一张屏幕截图                                                          |
| 3    | 游戏有失败判定                           | 10   | `4.png`                    | 在游戏失败时截图全屏                                                                                                                                      |
| 4    | 游戏中有交互音效                         | 10   | `code.zip`                 | 评分时不但会检查是否存在音效文件，还会测试音效的应用位置，请勿投机取巧。最好把资源文件放在 `src` 文件夹里面。`code.zip` 包含：`index.html` 和其他资源文件 |
| 5    | 代码流畅运行，游戏逻辑完整               | 15   | `game.mp4`                 | 录屏游戏完整运行过程，必须是**全屏录制**，禁止仅录制窗口                                                                                                  |
| 6    | 有游戏说明文件                           | 5    | `describe.md`              | 撰写游戏规则说明，自行发挥，但是要让其他人轻松了解游戏玩法                                                                                                |
| 7    | 实验报告                                 | 40   | `report.pdf`, `report.zip` | Markdown 格式实验报告（包含附件，打包为 `report.zip`），Typora 导出 `report.pdf` 文档                                                                     |

## 实验报告要求

请使用 Markdown 撰写实验报告，并包含以下内容：

1. 实验基本信息（5 分）
   - 姓名、学号、班级
   - 实验名称：Phaser 游戏开发
   - 实验日期（要与视频录制、截图时间一致）
2. 实验环境说明（5 分）
   - 操作系统（Windows/MacOS/Linux）
   - 浏览器（Chrome/Edge）
   - 编辑器
3. 实验过程描述（20 分）
   - 简述操作过程（至少 3 张图片）
   - 简述过程中遇到的问题与解决方案（肯定有问题）
4. 总结与感想（10 分）
   - 简述自己学到的思路/代码

## 操作步骤

如无游戏设计思路，可参考本文档同文件夹下的 `Code.zip` 查看成品，写了一些注释，以下教程中称此代码为**成品**。

### 0.准备工作

下载本仓库下与 JavaScript_game.md 同目录的`phaser.js`文件并在 index.html 中导入。

![](./assets/step0.png)

### 1.初始化 Phaser

在 body 元素内添加 script 标签，并添加如下 JS 代码初始化 Phaser 配置：

```javascript
var config = {
  type: Phaser.AUTO, // 渲染模式，建议选择Auto
  width: 1208, // canvas（游戏窗口）的宽度
  height: 668, // canvas（游戏窗口）的高度
  physics: {
    // 为游戏添加添加物理系统配置
    default: "arcade", // “街机”物理引擎
    arcade: {
      gravity: {
        // 重力参数
        y: 300,
      },
      debug: false, // 关闭调试模式
    },
  },
  scene: {
    // 场景默认配置函数
    preload: preload,
    create: create,
    update: update,
  },
};
var game = new Phaser.Game(config);
function preload() {
  // preload函数用于预加载游戏所需要的资源
  // 游戏内所有的资源都需要先导入再使用
}
function create() {
  // create函数用于为页面内添加资源，例如图片、音效等
}
function update() {
  // update函数会实时监听浏览器各种事件
  // 这个函数里面的代码一直在运行
}
```

之后我们尝试运行一下这个代码，注意这里有个坑，在选择打开方式时务必选择`Open with Live Server`，否则在之后的过程中资源将**无法加载**！

![](./assets/step1-1.png)

运行之后在浏览器查看，你会发现有一个 1208\*668（代码中的大小配置）的黑色区域被生成，不用担心，这并不是运行失败，因为我们还没有导入游戏资源。

![](./assets/step1-2.png)

这样 Phaser 库就被正常导入并且完美运行了。

### 2.导入游戏资源

游戏资源分为`图片资源`和`音频资源`，他们有着不同的导入方式：

```javascript
// 示例代码
function preload() {
  this.load.image("background", "res/background.png");
  this.load.audio("eat", "res/eat.mp3");
}
```

在以上示例代码中`this.load.image()`用于导入图片资源，而`this.load.audio()`用于导入音频资源。其中，括号内参数第一项是资源别名，在添加/使用资源时会用到，而第二个参数是文件路径，例如加载的`background`的位置是`res`文件夹下的`background.png`。

因此在`成品`中，我们这些代码都是为了导入游戏资源，对于游戏素材的获取方法，大家可以参考文章后面的[帮助-素材获取](#帮助)：

![](./assets/step2-1.png)

### 3.使用游戏资源

别忘了我们仅仅是导入了资源，现在运行结果仍然是黑屏，现在我们来加载图片资源：

```javascript
// 示例代码
function create() {
  this.add.image(604, 334, "background");
}
```

这行代码的意思是在坐标(604, 334)的位置添加一个别名为 background 的图片，Phaser 的坐标原点(0,0)在左上角。又因为我们的游戏画面大小是 1208\*668，所以添加的图片刚好在画面正中央。

添加这行代码之后，你会发现现在网页不再是黑屏了，有了游戏背景：

![](./assets/step3-1.png)

但是图片太小了，我们需要让图片大一些：

```javascript
// 示例代码
function create() {
  // this.add.image(604, 334, "background");
  // 更改为：
  this.add.image(604, 334, "background").setScale(4);
}
```

其中的 setScale()方法就是将图片缩放到原来的多少倍，代码中则是放大四倍，因此效果如下：

![](./assets/step3-2.png)

### 4.创建游戏角色

有了游戏画面，现在我们为游戏添加新的角色：

```javascript
function create() {
  // ...其他代码
  // 创建角色
  player = this.physics.add.sprite(580, 668, "stand").setScale(0.1);
  // 设置不可超出世界背景
  player.setCollideWorldBounds(true);
}
```

使用`this.physics.add.sprite()`添加人物素材，不难理解是在(580, 668)位置添加了一个`stand`素材，并且设置大小为 0.1.

之后便是设置 player 不能够超出世界背景了，直接使用`player.setCollideworldBounds(true)`即可做到。

现在我们可以看到人物被正常加载到了视图中：

![](./assets/step4-1.png)

### 5.让人物动起来

首先在 create 函数中创建键盘事件接收器：`cursors`:

```javascript
function create() {
  // ...其他代码
  cursors = this.input.keyboard.createCursorKeys();
}
```

cursors 可以接收键盘参数，这便于我们直接根据按键控制游戏人物。接下来就是在 update 函数中创建移动相关代码了：

```javascript
function create() {
  // ...其他代码
  playerState = "standing"; // 设置角色状态
}
function update() {
  // 设置人物在x方向的速度为0
  player.setVelocityX(0);
  // 跳跃
  if (cursors.up.isDown && player.body.onFloor()) {
    player.setVelocityY(-350);
    playerState = "jumping";
  }
  // 站立状态
  if (playerState !== "jumping" && player.body.velocity.x === 0) {
    playerState = "standing";
    player.setTexture("stand");
  }
  // 左右移动
  if (cursors.left.isDown) {
    player.setVelocityX(-250);
    player.setFlipX(true); // 翻转角色朝向
    if (playerState !== "jumping") {
      playerState = "walking";
      player.setTexture("walk");
    }
  } else if (cursors.right.isDown) {
    player.setVelocityX(250);
    player.setFlipX(false); // 恢复默认朝向
    if (playerState !== "jumping") {
      playerState = "walking";
      player.setTexture("walk");
    }
  }
  // 检测是否落地
  if (playerState == "jumping" && player.body.onFloor()) {
    playerState = "standing";
    player.setTexture("stand");
  }
}
```

添加完这些代码之后，我们的角色就能够走动和跳跃了。在上述代码中：

`cursors.left.down`等变量是开始定义的 cursors 的方法，他们监听键盘的上下左右按键。

`player.setVelocityX(100)`是给 player 一个 X 正向的 100 的速度。

`player.setTexture("walk")`是设置 player 显示的图像为 walk。

`player.body.onFloor()`是判断玩家是否接触了物理地面。

`player.setFlipX()`是设置玩家朝向是否反转。

还有其他的函数大家可以在 Phaser 官网进行查看。

### 6.创建物理平台

接下来该创建一个可以让人物站立的其他平台了：

```javascript
function create() {
  //...其他代码
  // 设置物理平台组
  platforms = this.physics.add.staticGroup();
  platforms.create(200, 500, "ground").setScale(0.3).refreshBody();
  // 添加碰撞效果
  this.physics.add.collider(player, platforms);
}
```

首先我们使用`this.physics.add.staticGroup();`创建一个平台组，之后使用 create 方法在(200, 500)的地方放置 ground 资源，并设置为 0.3 被大小。`refreshBody()`是刷新物理体积元素，在使用 setScale 时务必刷新物理体积，否则会形成“空气墙”效果。

现在我们操控人物可以站到平台上了：

![](./assets/step6-1.png)

### 7.创建收集物与炸弹

现在我们来写收集物与炸弹：

```javascript
function create() {
  //...其他代码
  // 添加掉落收集物
  coins = this.physics.add.group({
    key: "coin",
    repeat: 6, // 重复几个
    setXY: {
      x: 12, // x坐标
      y: 0, // y坐标
      stepX: 130, // 金币之间的间隔
    },
  });
  // 为每个子对象设置属性
  coins.children.iterate(function (child) {
    // 设置随机反弹强度（0.4到0.9之间）
    child.setBounceY(Phaser.Math.FloatBetween(0.4, 0.9));
    // 设置大小（因为素材图片太大）
    child.setScale(0.2);
    // 设置金币不超出世界边界
    child.setCollideWorldBounds(true);
    // 添加一些随机角度的旋转效果
    child.setAngularVelocity(Phaser.Math.Between(-100, 100));
  });
  // 设置金币与平台碰撞事件
  this.physics.add.collider(coins, platforms);
  // 设置吃金币事件
  this.physics.add.overlap(player, coins, collectCoin, null, this);
}
```

在上面的代码中，我们使用`this.physics.add.group()`创建了多个金币的生成，并使用 children 对其进行遍历来设置属性。

在设置吃金币的事件中，我们使用了`this.physics.add.overlap(player, coins, collectCoin, null, this);`，其中 player 为玩家对象，就是之前代码中写的 player，coins 指的是设置的金币对象组，collectCoin 是处理金币与 player 重叠时的事件函数，下面我们来编写这个函数：

```javascript
function collectCoin() {
  coin.disableBody(true, true); // 销毁当前金币对象（因为已经被player“吃掉了”）
  // 分数+1
  score += 1;
  // 播放音效
  this.sound.play("ji", {
    volume: 1,
    rate: 1,
  });
  // 如果所有金币被吃完就生成新的金币
  if (coins.countActive(true) === 0) {
    // 播放音效
    this.sound.play("jinitaimei", {
      volume: 1,
      rate: 1,
    });
    // 使得每个金币元素重新激活
    coins.children.iterate(function (child) {
      child.enableBody(true, child.x, 0, true, true);
    });
  }
}
```

当然，这个代码也需要写生成炸弹的代码：

```javascript
function collectCoin() {
  //...其他代码
  // 生成炸弹：条件是每吃7个金币，就生成一个炸弹
  if (score != 0 && score % 7 == 0) {
    letter = this.physics.add.group({
      key: "letter",
      repeat: 0,
      setXY: {
        x: 1280,
        y: 100,
        stepX: 130,
      },
    });
    letter.children.iterate(function (child) {
      // 设置大小
      child.setScale(0.8);
      // 设置与世界边界碰撞
      child.setCollideWorldBounds(true);
      // 弹性碰撞
      child.setBounce(1.0025);
      // 计算向左下角发射的随机角度（180°到270°之间）
      const angle = Phaser.Math.Between(180, 270);
      // 随机速度
      const speed = Phaser.Math.Between(150, 250);
      // 将角度和速度转换为x和y速度分量
      const rad = Phaser.Math.DegToRad(angle);
      child.setVelocity(Math.cos(rad) * speed, Math.sin(rad) * speed);
      // 添加一些随机旋转效果
      child.setAngularVelocity(Phaser.Math.Between(-100, 100));
    });
    // 设置与平台碰撞
    this.physics.add.collider(letter, platforms);
    // 设置与玩家碰撞
    this.physics.add.overlap(player, letter, collectLetter, null, this);
  }
}
// 收集到炸弹的代码
function collectLetter(player, letter) {
  // 播放音效
  this.sound.play("niganma", {
    volume: 1,
    rate: 1,
  });
  // 使得自身消失
  letter.disableBody(true, true);
  // 收集炸弹时letter（炸弹）数量+1
  letterNum += 1;
}
```

大家可能发现，生成炸弹的逻辑是`score != 0 && score % 7 == 0`,但是 score 并没有定义，所以我们需要在 create 函数中进行定义，当然炸弹也要定义：

```javascript
function create() {
  //...其他代码
  score = 0;
  letterNUm = 0; // 吃到的炸弹数量
}
```

完成上面的代码后，你就可以得到一个可以正常运行的游戏了。

### 8.分数展示

但是，以上还不够，我们的游戏还要有流程的控制：什么时候失败？

在`成品`中，当收集到 5 个 letter 后就会出发 GameOver 的操作，所以我们需要一个显示的文本，让玩家知道自己的分数：

```javascript
function create() {
  //...其他代码
  scoreText = "";
  scoreText = this.add.text(16, 16, "得分：0\n\n律师函：0", {
    fontSize: "32px",
    fill: "#000",
  });
}
```

上述代码就会在页面的(16,16)位置生成 一个初始化的得分文本：

![](./assets/step8-1.png)

同样的，我们要在吃到金币和 letter（炸弹）时刷新文本：

```javascript
function collectCoin() {
  //...其他代码
  scoreText.setText("得分：" + score + "\n\n" + "律师函：" + letterNum);
}
function collectLetter() {
  //...其他代码
  scoreText.setText("得分：" + score + "\n\n" + "律师函：" + letterNum);
}
```

这样，我们就能够在游戏画面上实时展示分数了。

### 9.设置游戏结束条件

一个游戏是至少要有结束条件的，我们的思路是当吃到 letter（炸弹）时，吃到炸弹总数为 5 时游戏结束，所以我们要在 collectLetter 函数上做文章了：

```javascript
function collectLetter() {
  //...其他代码
  // 判定游戏结束
  if (letterNum == 5) {
    // 定时1.5秒
    setTimeout(() => {
      // 播放音效
      this.sound.play("gameover", {
        volume: 1,
        rate: 1,
      });
      // 暂停游戏
      this.physics.pause();
      // 添加游戏结束图片
      this.add.image(600, 334, "gameoverRes").setScale(3);
      // 添加游戏结束文本
      this.add.text(400, 310, "Game Over", {
        fontSize: "100px",
        fill: "#000",
      });
    }, 1500);
  }
}
```

这样我们就可以有游戏结束画面了：

![](./assets/step9-1.png)

### 10.美化网页界面

大家也发现了，我们的游戏画面在开发者控制台显示为一个`canvas`元素，所以我们可以直接用属性选择器操作它的样式：

```css
canvas {
  display: block;
  margin: 0 auto;
}
```

这样游戏画面就居中显示了：

![](./assets/step10-1.png)

## 帮助

### 1.素材获取

大家可以用大模型文生图的方式获取人物素材，可以使用的是[豆包](https://www.doubao.com/chat/)，例如：

![](./assets/help1-1.png)

由于生成的图片自带背景颜色，可以用三方工具进行抠图，例如在线抠图工具：[扣扣图](https://www.koukoutu.com/removebgtool/all)

![](./assets/help1-2.png)

### 2.视频录制

录制必须要录制全屏，包含完整的游戏过程，建议使用 [OBS](https://obsproject.com/)，也可以用其他录屏软件，切记全屏幕录制！
