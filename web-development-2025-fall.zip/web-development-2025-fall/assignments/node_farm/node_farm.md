# Node 农场

## 致谢

感谢 2021 级软件工程专业张岩同学为本作业编写示例代码。

感谢 2022 级软件工程专业任宏雲为本作业编写示例过程。

## 基本要求

请根据以下要求完成作业：

1. 安装 Node.js；
2. 新建`index.js`文件，尝试 JavaScript 构建简单服务器；
3. 根据`./dev-data/data.json`、`./templates/overview.html`和`./templates/product.html`文件内容，建立通过 JavaScript 动态生成路由和 HTML 的 NODE FARM 服务；
4. 创建`./modules/replaceTemplate.js`，将`replaceTemplate`函数独立为 module；
5. 在作业目录内，使用`npm init`创建`package.json`，本地安装`slugify`，开发安装`nodemon`，设置`package.json`中`script`部分。使用`npm start`执行`nodemon index.js`启动服务器。

**注意**：示例图片内容可能已过期，请大家根据实际情况自行调整目录、文件名相关内容的命令行。

## 评分标准

作业将按照以下标准进行评分：

| 编号 | 描述                                                        | 分值 | 提交文件 | 备注                                                                                 |
| ---- | ----------------------------------------------------------- | ---- | -------- | ------------------------------------------------------------------------------------ |
| 1    | 创建`index.js`文件，在本地 8000 端口运行服务器              | 10   | `1.png`  | 桌面截图，显示在终端运行`node server.js`                                             |
| 2    | `.html`文件内有关蔬菜的具体信息更换为`{$XXX$}`的形式        | 10   | `2.png`  | 桌面截图，显示核心代码                                                               |
| 3    | 访问`http://127.0.0.1:8000/overview`可以得到 NODE FARM 主页 | 10   | `3.png`  | 桌面截图，显示浏览器及完整的 NODE FARM 主页                                          |
| 4    | NODE FARM 主页蔬菜信息来自`./dev-data/data.json`            | 10   | `4.png`  | 桌面截图，显示浏览器及完整的 NODE FARM 主页                                          |
| 5    | 点击 NODE FARM 主页的蔬菜的 DETAIL，可以链接到详细蔬菜信息  | 20   | `5.png`  | 桌面截图，显示浏览器访问任意`/product`路由（带查询参数）                             |
| 6    | 创建独立的`./modules/replaceTemplate.js`                    | 10   | `6.png`  | 桌面截图，显示`relpaceTemplate.js`内容，显示引用`replaceTemplate`module 的核心代码   |
| 7    | `npm init`创建`package.json`文件                            | 10   | `7.png`  | 桌面截图，显示项目目录名称，显示`package.json`内容                                   |
| 8    | 本地安装`slugify`，开发安装`nodemon`                        | 10   | `7.png`  | 桌面截图，显示项目目录名称，显示`package.json`内容                                   |
| 9    | 配置`package.json`，使用`npm start`执行`nodemon`版服务器    | 10   | `8.png`  | 桌面截图，显示终端内执行`npm start`结果，浏览器内显示`http://127.0.0.1:8000`页面内容 |
| 10   | 撰写实验报告，内容包括实验目的、过程、遇到的问题及解决方法、实验总结 | 10   | `report.md` | 提交`report.md`，内容详实、条理清晰 |

## 作业示例

![image-20240511110607427](assets/image-20240511110607427.png)

![image-20240511110623949](assets/image-20240511110623949.png)

## 详细步骤

1. 安装[Node.js](https://nodejs.org/en)

2. 新建文件夹，加入课程压缩包内的`dev-data`、`template`文件夹

3. 文件夹根目录下新建`index.js`，建立 Node.js 服务器。打开一个终端，使用`node index.js`命令运行`index.js`文件

   ```javascript
   const fs = require("fs");
   const http = require("http");
   const url = require("url");

   const data = fs.readFileSync(`${__dirname}/dev-data/data.json`, `utf-8`);
   const dataObj = JSON.parse(data);

   const server = http.createServer((req, res) => {
     const pathName = req.url;
     if (pathName === "/" || pathName === "/overview") {
       res.end("This is the OVERVIEW");
     } else if (pathName === "/product") {
       res.end("This is the PRODUCT");
     } else if (pathName === "/api") {
       res.writeHead(200, {
         "Content-type": "application/json",
         "Access-Control-Allow-Origin": "*",
         "Access-Control-Allow-Headers": "*",
         "Access-Control-Allow-Methods": "PUT, POST, PATCH, DELETE, GET",
       });
       res.end(data);
     } else {
       res.writeHead(404, {
         "Content-type": "text/html",
         "my-own-header": "hello-world",
       });
       res.end("<h1>Page no found!</h1>");
     }
   });

   server.listen(8000, "127.0.0.1", () => {
     console.log("Listening to requests on port 8000");
   });
   ```

4. 检查`overview.html`，根据`<div class="cards-container">`内的内容，将`overview.html`分离为`template-overview.html`和`template-card.html`。分离规则：将`<div class="cards-container">`的内容单独分离为`template-card.html`，并保留该 div 的位置

5. 内容替换规则：

   - `productName` - `{%NAME%}`
   - `image` - `{%IMAGE%}`
   - `price` - `{%PRICE%}`
   - `from` - `{%FROM%}`
   - `nutrients` - `{%NUTRIENTS%}`
   - `quantity` - `{%QUANTITY%}`
   - `description` - `{%DESCRIPTION%}`
   - `id` - `{%ID%}`
   - `not-organic` - `{%NOT_ORGANIC%}`

   注意：参考样式表，`.not-organic`用来判断是否显示`ORGANIC!`字样，该 class 需要在`.html`文件内自行添加

   如：`template-card.html`内：

   ```js
   <div class="card__detail-box {%NOT_ORGANIC%}">
     <h6 class="card__detail card__detail--organic">organic!</h6>
   </div>
   ```

   `template-product.html`内：

   ```js
   <div class="product__organic {%NOT_ORGANIC%}">
     <h5>Organic</h5>
   </div>
   ```

6. 检查`product.html`，修改文件名为`template-product.html`，同时使用 5 的替换规则替换相应内容

7. 修改`index.js`，增加 JSON 映射模板，在`/overview`和`/product`路由下增加映射后的页面

   ```javascript
   const fs = require("fs");
   const http = require("http");
   const url = require("url");

   const replaceTemplate = (temp, product) => {
     let output = temp.replace(/{%NAME%}/g, product.productName);
     output = output.replace(/{%IMAGE%}/g, product.image);
     output = output.replace(/{%PRICE%}/g, product.price);
     output = output.replace(/{%FROM%}/g, product.from);
     output = output.replace(/{%NUTRIENTS%}/g, product.nutrients);
     output = output.replace(/{%QUANTITY%}/g, product.quantity);
     output = output.replace(/{%DESCRIPTION%}/g, product.description);
     output = output.replace(/{%ID%}/g, product.id);
     if (!product.organic)
       output = output.replace(/{%NOT_ORGANIC%}/g, "not-organic");
     return output;
   };

   const tempOverview = fs.readFileSync(
     `${__dirname}/templates/template-overview.html`,
     `utf-8`
   );
   const tempCard = fs.readFileSync(
     `${__dirname}/templates/template-card.html`,
     `utf-8`
   );
   const tempProduct = fs.readFileSync(
     `${__dirname}/templates/template-product.html`,
     `utf-8`
   );

   const data = fs.readFileSync(`${__dirname}/dev-data/data.json`, `utf-8`);
   const dataObj = JSON.parse(data);

   const server = http.createServer((req, res) => {
     const { query, pathname: pathName } = url.parse(req.url, true);

     // Overview
     if (pathName === "/" || pathName === "/overview") {
       res.writeHead(200, { "Content-type": "text/html" });
       const cardsHtml = dataObj
         .map((el) => replaceTemplate(tempCard, el))
         .join("");
       const output = tempOverview.replace("{%PRODUCT_CARDS%}", cardsHtml);
       res.end(output);

       // Product page
     } else if (pathName === "/product") {
       res.writeHead(200, { "Content-type": "text/html" });
       const product = dataObj[query.id];
       const output = replaceTemplate(tempProduct, product);
       res.end(output);

       // API
     } else if (pathName === "/api") {
       res.writeHead(200, {
         "Content-type": "application/json",
         "Access-Control-Allow-Origin": "*",
         "Access-Control-Allow-Headers": "*",
         "Access-Control-Allow-Methods": "PUT, POST, PATCH, DELETE, GET",
       });
       res.end(data);

       // Not found
     } else {
       res.writeHead(404, {
         "Content-type": "text/html",
         "my-own-header": "hello-world",
       });
       res.end("<h1>Page no found!</h1>");
     }
   });

   server.listen(8000, "127.0.0.1", () => {
     console.log("Listening to requests on port 8000");
   });
   ```

8. 创建并使用`replaceTemplate`模块

创建`modules/replaceTemplate.js`，放入`index.js`中的`replaceTemplate`函数。

将`const replaceTemplate`替换为`module.exports =`。

这样，就可以在`index.js`中使用自定义的 module：

```javascript
const replaceTemplate = require("./modules/replaceTemplate");
```

9. `npm`项目管理

使用终端进入作业目录，执行`npm init`创建`package.json`文件。

执行`npm install slugify`本地安装`slugify`。

执行`npm install nodemon --save-dev`开发安装`nodemon`。

编辑`package.json`，增加以下配置：

```javascript
"scripts": {
  "start": "nodemon index.js"
}
```

这样，就可以执行`npm start`运行`nodemon`版服务器。

## 实验报告撰写要求

请在作业目录下新建`report.md`文件，内容包括：

> 本次实验是模仿动态网页的生成过程，请结合实验内容进行总结和反思。

1. 实验目的：简要说明本次实验的目标和意义，突出本实验是模仿动态网页生成过程。
2. 实验过程：描述主要的操作步骤和实现思路。
3. 遇到的问题及解决方法：列举实验过程中遇到的主要问题及你的解决办法。
4. 实验总结：对本次实验的收获、体会或改进建议进行总结，建议结合动态网页生成的理解进行阐述。

实验报告要求内容详实、条理清晰，字数不少于300字。

## 扩展练习

扩展练习属于课外推荐练习，不计入评分。

### 扩展练习 1：MVC 模式中的 HTML

MVC 模式（Model–view–controller）是软件工程中的一种软件架构模式，把软件系统分为三个基本部分：模型（Model）、视图（View）和控制器（Controller）：

- 模型（Model） - 程序员编写程序应有的功能（实现算法等等）、数据库专家进行数据管理和数据库设计(可以实现具体的功能)。
- 视图（View） - 界面设计人员进行图形界面设计。
- 控制器（Controller）- 负责转发请求，对请求进行处理。

![image-20230511183041630](assets/image-20230511183041630.png)

![image-20230511183050622](assets/image-20230511183050622.png)

#### 总体要求

1. 安装[Git](https://git-scm.com/)工具，下载实验代码。

```
   # git clone http://www.chenhaotian.cn:1780/chenhaotian/web2022spring-hw-htmooc
```

2. 检查`app/templates/exam/examing.html`，尝试将 Jinja2 模板引擎部分（即`{% %}`和`{{ }}`）替换为试题，并另存为独立 HTML 文件。

3. 备选试题见`app/question.csv`。每人从题库内任选试题，但**禁止和作业范例内的试题重复**。

#### 作业范例

![image-20230511183139090](assets/image-20230511183139090.png)

## 参考资料

- Miguel Grinberg. Flask Web 开发实战——基于 Python 的 Web 应用开发实战
- [udemy - Node.js, Express, MongoDB & More: The Complete Bootcamp](https://www.udemy.com/course/nodejs-express-mongodb-bootcamp/)
- [Node.js 教程](https://www.runoob.com/nodejs/nodejs-tutorial.html)
- [廖雪峰的官方网站——Git](https://www.liaoxuefeng.com/wiki/896043488029600)
- [The Missing Semester of Your CS Education](https://missing.csail.mit.edu/)
